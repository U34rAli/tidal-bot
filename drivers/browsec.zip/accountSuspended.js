/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
const _browser = typeof browser !== 'undefined' ? browser : chrome;

_browser.runtime.onMessage.addListener((message, sender) => {
  if (sender.id !== _browser.runtime.id || sender.origin !== 'null') return;
  if (!(message === null || message === void 0 ? void 0 : message['show update payment info'])) return;
  const element = document.querySelector('.paddle_button.nolink');
  if (element) element.click();
});
/******/ })()
;